# Cuenta regresiva con pausa
import time

# Solicita al usuario que ingrese el número inicial para la cuenta regresiva
numero = int(input("Ingresa el número desde el cual comenzar la cuenta regresiva: "))

# Realiza la cuenta regresiva
for i in range(numero, 0, -1):
    print(i)
    time.sleep(1)  # Pausa de 1 segundo entre cada número

# Al final de la cuenta regresiva
print("¡Despegue!")
