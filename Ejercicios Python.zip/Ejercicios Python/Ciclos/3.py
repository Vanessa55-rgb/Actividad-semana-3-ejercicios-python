# Sumar N números
# Solicita al usuario que ingrese un número N
N = int(input("Ingresa un número N: "))

# Inicializa la variable para almacenar la suma
suma = 0

# Usa un ciclo for para sumar los primeros N números naturales
for i in range(1, N + 1):
    suma += i

# Muestra el resultado
print(f"La suma de los primeros {N} números naturales es: {suma}")
