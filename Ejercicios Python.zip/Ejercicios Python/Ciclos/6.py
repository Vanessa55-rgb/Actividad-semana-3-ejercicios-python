# Número secreto
import random

# Genera un número secreto aleatorio entre 1 y 100
numero_secreto = random.randint(1, 100)

# Inicializa la variable para contar intentos
intentos = 0

# Inicia el juego
print("¡Bienvenido al juego del número secreto!")
print("Estoy pensando en un número entre 1 y 100. ¡Intenta adivinarlo!")

# Bucle para permitir múltiples intentos
while True:
    # Solicita al usuario que ingrese un número
    intento = int(input("Ingresa tu intento: "))
    intentos += 1
    
    # Compara el intento con el número secreto
    if intento < numero_secreto:
        print("Demasiado bajo. Intenta de nuevo.")
    elif intento > numero_secreto:
        print("Demasiado alto. Intenta de nuevo.")
    else:
        print(f"¡Felicidades! Adivinaste el número secreto {numero_secreto} en {intentos} intentos.")
        break  # Termina el juego cuando se adivina el número
