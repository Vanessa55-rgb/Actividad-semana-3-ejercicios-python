# Contador descendente
# Inicializa el contador en 10
contador = 10

# Usa un ciclo while para contar de forma descendente
while contador >= 1:
    print(contador)
    contador -= 1  # Decrementa el contador en 1
