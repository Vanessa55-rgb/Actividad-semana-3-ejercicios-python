# Suma hasta número ingresado
# Solicita al usuario que ingrese un número
numero = int(input("Ingresa un número hasta el cual sumar: "))

# Inicializa la variable para almacenar la suma
suma = 0

# Usa un ciclo for para sumar todos los números desde 1 hasta el número ingresado
for i in range(1, numero + 1):
    suma += i

# Muestra el resultado
print(f"La suma de todos los números desde 1 hasta {numero} es: {suma}")
