# Tabla de multiplicar
# Solicita al usuario que ingrese un número
numero = int(input("Ingresa un número para mostrar su tabla de multiplicar: "))

# Usa un ciclo for para mostrar la tabla de multiplicar del número ingresado
for i in range(1, 11):
    print(f"{numero} x {i} = {numero * i}")
