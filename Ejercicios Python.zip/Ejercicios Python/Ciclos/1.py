# Contar del 1 al 10
# Usa un bucle for para contar del 1 al 10
for i in range(1, 11):
    print(i)
