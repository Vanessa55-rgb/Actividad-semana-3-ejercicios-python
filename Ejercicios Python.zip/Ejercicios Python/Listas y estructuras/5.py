# Lista de números de ejemplo
numeros = [10, 20, 5, 42, 15, 3, 8]

# Encontramos el número más grande y el más pequeño usando las funciones max() y min()
mayor = max(numeros)
menor = min(numeros)

# Mostramos los resultados
print(f"El número más grande de la lista es: {mayor}")
print(f"El número más pequeño de la lista es: {menor}")
