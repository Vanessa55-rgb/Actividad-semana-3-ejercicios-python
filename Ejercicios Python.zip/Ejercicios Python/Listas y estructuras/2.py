# Lista de números de ejemplo
numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Inicializamos las listas de pares e impares
pares = []
impares = []

# Recorremos cada número de la lista
for numero in numeros:
    if numero % 2 == 0:  # Si el número es divisible entre 2 (es par)
        pares.append(numero)
    else:  # Si no es divisible entre 2 (es impar)
        impares.append(numero)

# Mostramos los resultados
print(f"Lista de pares: {pares}")
print(f"Lista de impares: {impares}")
