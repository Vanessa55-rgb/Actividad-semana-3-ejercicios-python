# Lista de números de ejemplo
numeros = [10, 20, 30, 40, 50]

# Valor que queremos buscar
valor_buscar = 30

# Verificamos si el valor está en la lista
if valor_buscar in numeros:
    print(f"El valor {valor_buscar} está presente en la lista.")
else:
    print(f"El valor {valor_buscar} NO está presente en la lista.")
