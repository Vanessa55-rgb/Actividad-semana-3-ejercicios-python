# Lista con elementos duplicados
numeros = [1, 2, 3, 4, 2, 5, 3, 6, 7, 4]

# Eliminar duplicados utilizando set()
numeros_sin_duplicados = list(set(numeros))

# Mostrar la lista sin duplicados
print(f"Lista sin duplicados: {numeros_sin_duplicados}")
