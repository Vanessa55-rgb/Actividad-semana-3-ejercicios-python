# Inicializamos las variables para almacenar las calificaciones y el número de calificaciones
calificaciones = []
suma = 0

# Bucle para pedir las calificaciones
while True:
    # Pedir una calificación
    entrada = input("Ingresa una calificación (o 'fin' para terminar): ")
    
    # Si el usuario ingresa "fin", salimos del bucle
    if entrada.lower() == "fin":
        break
    
    # Intentamos convertir la entrada a un número
    try:
        calificacion = float(entrada)  # Usamos float para permitir decimales
        calificaciones.append(calificacion)  # Añadimos la calificación a la lista
        suma += calificacion  # Sumamos la calificación
    except ValueError:
        print("Por favor, ingresa una calificación válida.")

# Si hay calificaciones ingresadas, calculamos el promedio
if len(calificaciones) > 0:
    promedio = suma / len(calificaciones)
    print(f"El promedio de las calificaciones es: {promedio}")
else:
    print("No se ingresaron calificaciones.")
