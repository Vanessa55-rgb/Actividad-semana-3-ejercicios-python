# Inicializamos la suma en 0
suma = 0

# Bucle para pedir los números
while True:
    # Pedir al usuario un número o "fin"
    entrada = input("Ingresa un número (o 'fin' para terminar): ")
    
    # Si el usuario ingresa "fin", salimos del bucle
    if entrada.lower() == "fin":
        break
    
    # Intentamos convertir la entrada a número
    try:
        numero = float(entrada)  # Usamos float para permitir números decimales
        suma += numero
    except ValueError:
        print("Por favor, ingresa un número válido.")

# Mostramos el
