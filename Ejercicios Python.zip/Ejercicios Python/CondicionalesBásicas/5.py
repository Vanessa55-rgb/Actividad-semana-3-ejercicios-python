# Aprobado o reprobado
# Solicita al usuario que ingrese una calificación
calificacion = float(input("Ingresa tu calificación (0 a 10): "))

# Verifica si la calificación está en el rango válido
if calificacion < 0 or calificacion > 10:
    print("Calificación no válida. Debe estar entre 0 y 10.")
elif calificacion >= 6:
    print("¡Aprobado!")
else:
    print("Reprobado.")
