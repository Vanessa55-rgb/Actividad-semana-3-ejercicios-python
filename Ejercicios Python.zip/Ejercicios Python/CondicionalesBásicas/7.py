# Comparar tres números
# Solicita al usuario que ingrese tres números
num1 = float(input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
num3 = float(input("Ingresa el tercer número: "))

# Determina el mayor valor
mayor = max(num1, num2, num3)

# Verifica cuántos números son iguales al mayor
iguales = []
if num1 == mayor:
    iguales.append("primer número")
if num2 == mayor:
    iguales.append("segundo número")
if num3 == mayor:
    iguales.append("tercer número")

# Muestra el resultado
if len(iguales) == 1:
    print(f"El {iguales[0]} es el mayor.")
elif len(iguales) == 2:
    print(f"El {iguales[0]} y el {iguales[1]} son los mayores (iguales).")
else:
    print("Los tres números son iguales.")
