# Par o impar
# Solicita al usuario que ingrese un número entero
numero = int(input("Ingresa un número entero: "))

# Verifica si es par o impar usando el operador módulo (%)
if numero % 2 == 0:
    print("El número es par.")
else:
    print("El número es impar.")
