# Validar contraseña
# Establece la contraseña correcta
contraseña_correcta = "MiContraseña123"

# Solicita al usuario que ingrese la contraseña
contraseña_ingresada = input("Ingresa tu contraseña: ")

# Compara la contraseña ingresada con la correcta
if contraseña_ingresada == contraseña_correcta:
    print("Contraseña correcta. Acceso permitido.")
else:
    print("Contraseña incorrecta. Acceso denegado.")
