# Múltiplo de 3 y/o 5
# Solicita al usuario que ingrese un número entero
numero = int(input("Ingresa un número entero: "))

# Verifica múltiplos
if numero % 3 == 0 and numero % 5 == 0:
    print("El número es múltiplo de 3 y de 5.")
elif numero % 3 == 0:
    print("El número es múltiplo de 3.")
elif numero % 5 == 0:
    print("El número es múltiplo de 5.")
else:
    print("El número no es múltiplo ni de 3 ni de 5.")
