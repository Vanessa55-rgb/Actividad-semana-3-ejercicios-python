# Clasificación de edad
# Solicita al usuario que ingrese su edad
edad = int(input("Ingresa tu edad: "))

# Clasifica según la edad
if edad < 0:
    print("Edad no válida.")
elif edad <= 12:
    print("Eres un niño.")
elif edad <= 17:
    print("Eres un adolescente.")
elif edad <= 59:
    print("Eres un adulto.")
else:
    print("Eres un anciano.")
